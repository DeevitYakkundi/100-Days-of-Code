# print("hello world!")
# print("Hello " + input("What is your name?"))

# x = input("Type a word?")
# print(len(x))


