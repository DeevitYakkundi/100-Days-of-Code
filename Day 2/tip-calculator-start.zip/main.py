print("Welcome to the tip calculator!")
bill = float(input("Enter the total bill?\n"))
people = int(input("Enter number of people split between?\n"))
tip = int(input("Tip percentage?\n"))

split = round((bill / people) * ((100 + tip) / 100), 2)
print(f"Each person has to pay {split}$")
print(f"Total tip amount is {(150 * tip)/ 100}")
