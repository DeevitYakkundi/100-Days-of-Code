print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))
bill = 0
if height >= 120:
    print("You can ride the rollercoster!!")
    age = int(input("What is your age?"))
    if age < 12:
        bill += 5
        print("Pay 5$")
    elif age <= 18:
        bill += 7
        print("Pay 7$")
    elif age >= 45 & age <= 55:
        print("Free ride")
    else:
        bill += 12
        print("Pay 12$")

    wants_photo = input("Want a photo? Y or N.")
    if wants_photo == "Y" or "y":
        bill += 3
        print(f"Your bill is {bill}")

else:
    print("You cannot ride the rollercoster :(")
