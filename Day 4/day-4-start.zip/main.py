import random
random_interger = random.randint(1,10)
print(random_interger)

